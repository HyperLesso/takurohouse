<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head itemscope itemtype="http://schema.org/WebSite">
    <base href="https://kasasushi.vn/" />
    <title> | KASA SUSHI ・【傘寿司】</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Content-Language" content="vi, en">
    <meta name="robots" content="index,follow">
    <meta name="copyright" content="AZApp.vn">
    <meta name="apple-mobile-web-app-title" content=" | KASA SUSHI ・【傘寿司】">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <meta property="og:site_name" content=" | KASA SUSHI ・【傘寿司】" />
    <meta property="og:url" content="https://kasasushi.vn/restserver.php" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content=" | KASA SUSHI ・【傘寿司】" />
    <meta property="og:description" content="Tại Kasa Sushi, chúng tôi đề cao dịch vụ tận tâm và đặt khách hàng lên trên hết, bằng việc phục vụ bạn những món ăn Nhật Bản ngon mắt, hương vị chuẩn Nhật với mức giá phù hợp, chẳng cần bao bì quá cầu kỳ hay cao cấp." />
    <meta name="description" content="Tại Kasa Sushi, chúng tôi đề cao dịch vụ tận tâm và đặt khách hàng lên trên hết, bằng việc phục vụ bạn những món ăn Nhật Bản ngon mắt, hương vị chuẩn Nhật với mức giá phù hợp, chẳng cần bao bì quá cầu kỳ hay cao cấp." />
    <meta property="og:image" content="https://kasasushi.vn/assets/images/sponsor-fb.jpg"/>
    <meta property="og:image:width" content="630"/>
    <meta property="og:image:height" content="315"/>
    <meta property="og:image:alt" content=" | KASA SUSHI ・【傘寿司】"/>
    <meta property="article:publisher" content="" />
    <meta property="article:author" content="" />

    <link rel="shortcut icon" href="assets/images/favicon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
    <meta name="theme-color" content="#173730">
    <meta name="msapplication-navbutton-color" content="#173730">
    <meta name="apple-mobile-web-app-status-bar-style" content="#173730">
    <meta name="apple-touch-fullscreen" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="no">
    <meta name="format-detection" content="telephone=no">
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />

    <script type="text/javascript">
        var site_url = 'https://kasasushi.vn/';
        var current_url = 'https://kasasushi.vn/restserver.php';
        var today = new Date();
        var return_url = '';
        var token = '';
    </script>
    <link rel="stylesheet" type="text/css" href="assets/css/semantic.min.css?v=202203101700"/>
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/owl.theme.green.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/sweetalert2.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/calendar.css" />
    <link rel="stylesheet" type="text/css" href="assets/css/select2.min.css" />
    <link rel="stylesheet" type="text/css" href="assets/css/style.css?v=202203101700"/>
    <link rel="stylesheet" type="text/css" href="assets/css/main.css?v=202203101700"/>
    <script type="text/javascript" src="assets/js/jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="assets/js/semantic.min.js"></script>
    <script type="text/javascript" src="assets/js/components/calendar.min.js"></script>
    <script type="text/javascript" src="assets/js/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.sticky.js"></script>
    <script type="text/javascript" src="assets/js/jquery.cookie.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="assets/js/sweetalert2.min.js"></script>
    <script type="text/javascript" src="assets/js/lazyload.js"></script>
    <script type="text/javascript" src="assets/js/autoNumeric.min.js"></script>
    <script type="text/javascript" src="assets/js/sticky-sidebar.js"></script>
    <script type="text/javascript" src="assets/js/select2.min.js"></script>
    <script type="text/javascript" src="assets/js/main.js?v=202203101700"></script>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Z6JTNEV1JT"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Z6JTNEV1JT');
</script>    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5HWT2C4');</script>
<!-- End Google Tag Manager -->    <style type="text/css">
        @-webkit-keyframes spinAround{0%{transform:rotate(0deg)}to{transform:rotate(359deg)}}
        @keyframes spinAround{0%{transform:rotate(0deg)}to{transform:rotate(359deg)}}

        .loading-overlay {
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
            align-items: center;
            display: none;
            justify-content: center;
            overflow: hidden;
            z-index: 1;
        }

        .loading-overlay.is-active {
            display: flex;
        }

        .loading-overlay.is-full-page {
            z-index: 999;
            position: fixed;
        }

        .loading-overlay .loading-background {
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
            background: rgba(255,255,255,.7)!important;
        }

        .loading-overlay .loading-icon {
            position: relative;
        }

        .loading-overlay .loading-icon:after {
            -webkit-animation: spinAround .5s linear infinite;
            animation: spinAround .5s linear infinite;
            border-radius: 290486px;
            content: "";
            display: block;
            position: absolute;
            top: calc(50% - 1.5em);
            left: calc(50% - 1.5em);
            width: 3em;
            height: 3em;
            border-color: transparent transparent #777 #777;
            border-style: solid;
            border-width: .25em;
        }

        .loading-overlay .loading-icon:after {
            border-color: transparent transparent #173730 #173730!important;
            border-style: solid!important;
            border-width: 2px!important;
        }

        .loading-overlay.is-full-page .loading-icon:after {
            top: calc(50% - 2.5em);
            left: calc(50% - 2.5em);
            width: 5em;
            height: 5em;
        }

        .ui.dimmer {
            z-index: 9999;
        }

        #detailFrm .detail-images .item img {
            object-fit: fill;
        }

        .select2-container--open {
            z-index: 111111;
        }

        .fn-menupanel {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
        }

        .fn-menupanel-toggle span,
        .fn-menupanel-toggle span:after,
        .fn-menupanel-toggle span:before {
            width: 18px;
        }

        .fn-menupanel-toggle span:before {
            top: -7px;
        }

        .fn-menupanel-toggle span:after {
            top: 7px;
        }

        .fn-menu-open:not(.dimmed) .fn-menupanel-toggle span:before {
            top: 5px;
        }

        .fn-menu-open:not(.dimmed) .fn-menupanel-toggle span:after {
            top: -5px;
        }

        .image-cover {
            position: relative;
        }

        .image-cover .overlay {
            position: absolute;
            top: 0;
            bottom: 0;
            height: 100%;
            left: -1px;
            right: -1px;
            background-color: rgba(0,0,0,.24);
            -webkit-transition: opacity .6s,-webkit-transform .3s;
            transition: opacity .6s,-webkit-transform .3s;
            -o-transition: transform .3s,opacity .6s;
            transition: transform .3s,opacity .6s;
            transition: transform .3s,opacity .6s,-webkit-transform .3s;
            pointer-events: none;
        }

        .image-cover:hover .overlay {
            opacity: 0;
        }

        #main-menu ul li {
            padding: 15px 0;
            margin: 0 20px;
            min-width: unset;
        }

        #main-menu ul li.logo {
            padding: 0;
        }

        #main-menu ul.main-menu li > a {
            border-bottom: 1px solid transparent;
            padding: 0;
            padding-bottom: 5px;
            display: inherit;
        }

        #main-menu ul.main-menu li > a:hover,
        #main-menu ul.main-menu li.active > a {
            border-bottom: 1px solid #000;
        }

        #page .banner-link {
            position: absolute;
            left: 0;
            right: 0;
            text-align: center;
            bottom: 30px;
        }

        #page .banner-link-button {
            border: 1px solid #fff;
            background-color: transparent;
            color: #fff;
            -webkit-transition: border .3s,background .3s,opacity .3s,color .3s,-webkit-transform .3s,-webkit-box-shadow .3s;
            transition: border .3s,background .3s,opacity .3s,color .3s,-webkit-transform .3s,-webkit-box-shadow .3s;
            -o-transition: transform .3s,border .3s,background .3s,box-shadow .3s,opacity .3s,color .3s;
            transition: transform .3s,border .3s,background .3s,box-shadow .3s,opacity .3s,color .3s;
            transition: transform .3s,border .3s,background .3s,box-shadow .3s,opacity .3s,color .3s,-webkit-transform .3s,-webkit-box-shadow .3s;
            opacity: 0.85;
            font-weight: normal;
        }

        .image-cover:hover .banner-link-button,
        #page .banner-link-button:hover {
            opacity: 1;
        }

        @media only screen and (max-width: 767px) {
            .image-cover .overlay {
                opacity: 0;
            }
        }

        @media only screen and (min-width: 768px) {
            #main-menu ul li.logo a {
                position: relative;
            }

            #header .logo img {
                width: auto;
                height: 73px;
                position: absolute;
                top: 0;
                left: -85px;
            }
        }
    </style>
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5HWT2C4"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><div tabindex="0" aria-live="polite" aria-label="Loading" class="loading-overlay is-active is-full-page">
    <div class="loading-background"></div>
    <div class="loading-icon"><img src="assets/images/logo-loader.png" alt="" style="width: 36px;"/></div>
</div>
<div id="topcontrol" title="Trên đầu trang"><i class="angle up icon"></i></div>
<div class="ui sticky" id="header">
        <div class="menu-mobile">
        <div class="order-cart-user">
            <a href="tel:0243 9955 990" style="margin-right: 5px;"><img src="assets/images/btn-call.svg" alt="" style="width: 24px;"/></a>
            <a href="javascript:;" data-lng="en" class="iconla" style="margin-right: 5px;"><img src="assets/images/btn-en.svg" alt="" style="width: 32px;"/></a>            <a href="javascript:;" class="shopping-cart">
                <img src="assets/images/cart-icon.svg" alt="" style="width: 24px;"/>
                <span class="cart-badge">0</span>
            </a>
            <a href="javascript:;" class="loginLink"><img src="assets/images/user-icon.svg" alt="" style="width: 32px;"/></a>        </div>
        <div class="fn-menupanel"><button type="button" class="fn-menupanel-toggle"><span></span></button></div>
    </div>
    <div class="fn-menu-opacity"></div>
    <div class="fn-menu">
        <ul class="fn-menu-ul account-menu">
            <li class="member">
                <table cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td width="100%" style="text-align: left;">
                            <div class="logo">
                                <a href="./" title=" | KASA SUSHI ・【傘寿司】"><img itemprop="image" src="upload/interface/thumbs/logo-trang-chu-1683780863.png" alt=" | KASA SUSHI ・【傘寿司】" /></a>                            </div>
                        </td>
                    </tr>
                </table>
            </li>
        </ul>
        <div class="ui divider" style="border-color: transparent;"></div>
        <div class="menu-wrapper">
            <table cellspacing="0" cellpadding="0" width="80%" style="margin: auto;">
                <tr>
                    <td width="100%"><a href="about-us"><span>VỀ CHÚNG TÔI</span></a></td>
                </tr>
                <tr>
                    <td><a href="menu"><span>MENU</span></a></td>
                </tr>
                <tr><td><a href="news-and-offers">Tin tức & Ưu đãi</a></td></tr>                <tr>
                    <td><a href="thanh-vien"><span>THÀNH VIÊN</span></a></td>
                </tr>
                <tr><td><a href="delivery">ĐẶT HÀNG</a></td></tr>
                <tr><td><a href="booking">ĐẶT BÀN</a></td></tr>
                <tr><td><a href="catering">ĐẶT TIỆC</a></td></tr>
                <tr><td><a href="e-invoiced">HÓA ĐƠN ĐIỆN TỬ</a></td></tr>
                <tr>
                    <td style="border-bottom: 0;">
                        <div class="social-icons" style="position: static;">
                            <a href="https://www.facebook.com/kasasushi.jp" target="_blank" style="float: none; display: inline-block;"><i class="fa fa-facebook-f"></i></a>
                            <span>|</span>
                            <a href="https://www.instagram.com/kasa.sushi/" target="_blank"><i class="fa fa-instagram"></i></a>
                            <span>|</span>
                            <a href="javascript:;" data-lng="en" class="iconla" style="top: 0;">EN</a>                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div id="main-menu">
        <div class="ui container" style="position: relative;">
            <div class="social-icons">
                <a href="javascript:;" data-lng="en" class="iconla" style="top: 0;">EN</a>                <span>|</span>
                <a href="https://www.instagram.com/kasa.sushi/" target="_blank"><i class="fa fa-instagram"></i></a>
                <span>|</span>
                <a href="https://www.facebook.com/kasasushi.jp" target="_blank"><i class="fa fa-facebook-f"></i></a>
            </div>
            <div>
                <ul class="main-menu">
                    <li class="item logo">
                        <div class="logo">
                            <a href="./" title=" | KASA SUSHI ・【傘寿司】" class="desktop"><img itemprop="image" src="upload/interface/thumbs/logo-trang-chu-1683780863.png" alt=" | KASA SUSHI ・【傘寿司】" /></a><a href="./" title=" | KASA SUSHI ・【傘寿司】" class="mobile"><img itemprop="image" src="assets/images/logo-mobile.png" alt=" | KASA SUSHI ・【傘寿司】"/></a>                        </div>
                    </li>
                    <li class="item"><a href="about-us">VỀ CHÚNG TÔI</a></li>
                    <li class="item"><a href="menu">MENU</a></li>
                    <li class="item" style="padding-bottom: 0;"><a href="news-and-offers" style="max-width: 70px; margin: auto;">Tin tức & Ưu đãi</a></li>                    <li class="item"><a href="thanh-vien">THÀNH VIÊN</a></li>
                    <li class="item"><a href="delivery">ĐẶT HÀNG</a></li>
                    <li class="item"><a href="booking">ĐẶT BÀN</a></li>
                    <li class="item"><a href="catering">ĐẶT TIỆC</a></li>
                    <li class="item" style="width: 130px;"><a href="e-invoiced">HÓA ĐƠN ĐIỆN TỬ</a></li>
                </ul>
            </div>
            <div style="clear: both;"></div>
        </div>
    </div>
</div><link rel="stylesheet" type="text/css" href="assets/css/page.css?v=202203101700" />
<div class="ui container">
    <div class="ui stackable grid" id="page">
        <div class="sixteen wide column">
                        <div class="title-div">
                <h1></h1>
            </div>
                            <div class="ui stackable grid">
                    <div class="three wide column left-content">
                        <div class="bullet-top" style="text-align: center;"><img src="assets/images/bullet-top.png" alt=""></div>
                        <div id="page-menu">
                            <ul>
                                <li><a href="chinh-sach-dat-hang">CHÍNH SÁCH ĐẶT HÀNG</a></li><li><a href="chinh-sach-giao-hang">CHÍNH SÁCH GIAO HÀNG</a></li><li><a href="chinh-sach-doi-tra">CHÍNH SÁCH ĐỔI TRẢ</a></li><li><a href="chat-luong-san-pham">CHẤT LƯỢNG SẢN PHẨM</a></li><li><a href="thanh-vien">THÀNH VIÊN</a></li><li><a href="dat-tiec">ĐẶT TIỆC</a></li>                            </ul>
                        </div>
                    </div>
                    <div class="thirteen wide column">
                        <div class="line-ui">
                            <div style="text-align: center;"><img src="assets/images/bullet-top.png" alt="" style="visibility: hidden;"></div>
                        </div>
                        <div class="content-div medium-width">
                                                    </div>
                    </div>
                </div>
                        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('#page .detail-images').owlCarousel({
            animateOut: 'fadeOut',
            loop: true,
            lazyLoad: true,
            autoplay: true,
            autoplayTimeout: 5000,
            items: 1,
            margin: 0,
            stagePadding: 0,
            smartSpeed: 450,
            nav: false,
            navText: ['', '']
        });
    });
</script>    <div class="ui container">
        <div class="line-ui"></div>
    </div>
    <div id="footer" class="pusher">
        <div class="ui container">
                            <div class="ui grid">
                    <div class="eight wide column">
                        <a href="./" class="logo-footer"><img src="assets/images/footer-logo.svg" alt="" style="height: 24px; margin: 0;"></a>
                    </div>
                    <div class="eight wide column">
                        <div style="text-align: right; line-height: 24px;">2021 © NTP company               </div>
                    </div>
                </div>
                        </div>
    </div>
    <input type="hidden" id="call_back"/>
    <input type="hidden" name="token" value=""/>
            <div id="loginFrm" class="ui tiny longer modal">
            <a href="javascript:;" class="close"><img src="assets/images/close-icon.svg" alt=""/></a>
            <div class="header">ĐĂNG NHẬP</div>
            <form id="frmDangnhap" class="ui form" autocomplete="off">
                <div class="scrolling content">
                    <div class="field">
                        <label>Số điện thoại</label>
                        <div class="ui icon input">
                            <input type="tel" id="login_username" name="username" autocomplete="new-username" placeholder="">
                            <i class="user icon"></i>
                        </div>
                        <div class="errordiv login_username" style="top: 56px;"><div class="arrow"></div>Vui lòng nhập số điện thoại của bạn!</div>
                    </div>
                    <div class="field">
                        <label>Mật khẩu</label>
                        <div class="ui icon input">
                            <input type="password" id="login_password" name="password" autocomplete="new-password" placeholder="">
                            <i class="lock icon"></i>
                        </div>
                        <div class="errordiv login_password" style="top: 56px;"><div class="arrow"></div>Mật khẩu không thể để trống!</div>
                    </div>
                    <div class="inline field">
                        <a href="javascript:;" rel="nofollow" id="forgotLink" style="float: right; font-style: italic; font-weight: 400; font-size: 14px;">Quên mật khẩu</a>
                        <div class="ui checkbox">
                            <input type="checkbox" id="remember" name="remember" value="1" checked>
                            <label for="remember">GHI NHỚ TÀI KHOẢN</label>
                        </div>
                    </div>
                    <div class="field" style="text-align: center;">
                        <button type="submit" class="ui primary button">Đăng nhập</button>
                    </div>
                    <p style="text-align: center;">Bạn chưa có tài khoản? <a href="dang-ky" style="font-weight: bold;">Đăng ký</a></p>
                </div>
            </form>
        </div>
        <div id="forgotFrm" class="ui tiny longer modal">
            <a href="javascript:;" class="close"><img src="assets/images/close-icon.svg" alt=""/></a>
            <div class="header">QUÊN MẬT KHẨU</div>
            <form id="frmQuenmatkhau" class="ui form" autocomplete="off">
                <input type="hidden" id="forgot_step" value="request"/>
                <input type="hidden" name="id" value=""/>
                <div class="scrolling content">
                    <div class="field" id="step_request">
                        <label>Số điện thoại</label>
                        <div class="ui icon input">
                            <input type="tel" id="forgot_username" name="username" autocomplete="new-username" placeholder="">
                            <i class="user icon"></i>
                        </div>
                        <div class="errordiv forgot_username" style="top: 48px;"><div class="arrow"></div>Vui lòng nhập số điện thoại của bạn!</div>
                    </div>
                    <div class="field" id="step_confirm" style="display: none">
                        <div class="ui icon input">
                            <input type="text" id="forgot_confirm_code" name="confirm_code" value="" placeholder="Mã xác nhận" autocomplete="new-confirm_code">
                            <i class="code icon"></i>
                        </div>
                        <div style="text-align: left; margin: 10px 0;">Gửi đến số điện thoại đăng ký của bạn</div>
                        <div class="errordiv forgot_confirm_code" style="top: 48px;"><div class="arrow"></div>Vui lòng nhập mã xác nhận!</div>
                    </div>
                    <div id="step_final" style="display: none;">
                        <div class="field">
                            <label>Mật khẩu mới</label>
                            <div class="ui icon input">
                                <input type="password" id="forgot_new_password" name="new_password" autocomplete="new-password" placeholder=""/>
                                <i class="lock icon"></i>
                            </div>
                            <div style="text-align: left; margin: 10px 0;">Nhập mật khẩu mới để hoàn thành</div>
                            <div class="errordiv forgot_new_password" style="top: 48px;"><div class="arrow"></div>Vui lòng nhập mật khẩu mới!</div>
                        </div>
                    </div>
                    <div class="field" style="text-align: center;">
                        <button type="submit" class="ui primary button">Tiếp tục</button>
                    </div>
                </div>
            </form>
        </div>
            <div id="detailFrm" class="ui longer modal">
        <form id="frmDetail" class="ui form main-form" autocomplete="off">
            <div style="text-align: right;"><a class="close" href="javascript:;"><img src="assets/images/close-icon.svg" alt="" style="width: 21px;"/></a></div>
            <div class="ui two column stackable grid">
                <div class="wide column">
                    <div class="detail-images owl-carousel owl-theme"></div>
                </div>
                <div class="wide column">
                    <div class="content">
                        <div class="content-top">
                            <div class="title-detail"></div>
                            <div class="time-detail" style="float: left;"></div>
                            <div class="share-url" style="padding: 0; float: left;"></div>
                            <div style="clear: both;"></div>
                            <div class="scrolling info-detail"></div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div id="popupFrm" class="ui tiny modal">
        <a href="javascript:;" class="close"><img src="assets/images/close-icon.svg" alt="" style="width: 24px;"/></a>
        <div class="header">THÔNG BÁO</div>
        <div class="content">
            Xin lỗi, dịch vụ của chúng tôi chưa hỗ trợ giao hàng đến địa chỉ hiện tại của bạn. Vui lòng chọn địa chỉ khác hoặc liên hệ với chúng tôi theo số hotline
            <div><span><img src="assets/images/phone-icon.svg" alt="" style="width: 20px;"/> 0243 9955 990</span></div>
            để được hỗ trợ nhanh nhất
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function () {
                $('.loading-overlay').removeClass('is-active');
            }, 1000);

            $('body').on('click', '.cart-list .cart-item .del', function () {
                var $item = $(this).parent().parent().parent();
                $item.find('input.qty').val(0);
                updateCart($item);
                return false;
            }).on('click', '.cart-list .cart-item .down-qty', function () {
                var $item = $(this).parent().parent().parent().parent().parent();
                var qty = parseInt($item.find('input.qty').val()) - 1;
                if (qty <= 0) {
                    qty = 1;
                }
                $item.find('input.qty').val(qty);
                updateCart($item);
                return false;
            }).on('click', '.cart-list .cart-item .up-qty', function () {
                var $item = $(this).parent().parent().parent().parent().parent();
                var qty = parseInt($item.find('input.qty').val()) + 1;
                $item.find('input.qty').val(qty);
                updateCart($item);
                return false;
            }).on('change', '.cart-list .cart-item input.note', function () {
                updateCart($(this).parent().parent().parent().parent().parent());
            }).on('change', '.cart-list .cart-item .color', function () {
                var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
                $item.find('.item-price span').text($(this).data('price'));
                $('#confirm .cart-list .cart-item[data-id="' + $item.data('id') + '"] .item-price span').text($(this).data('price'));
                updateCart($item);
            }).on('change', 'input[name="pickup"]', function () {
                $.cookie('pickup', $(this).is(':checked') ? 1: 0);
                calcPayment();
            });

            $('#frmDangnhap').submit(function() {
                var username = $('#login_username').val().trim();
                var password = $('#login_password').val().trim();
                if (username == '') {
                    showErrOfField('login_username');
                    return false;
                }
                if (password == '') {
                    showErrOfField('login_password');
                    return false;
                }
                var frmData = $('#frmDangnhap').serializeArray();
                $('#frmDangnhap input[type="text"], #frmDangnhap button').attr('disabled', true);
                $('#frmDangnhap button[type="submit"]').addClass('loading');
                $.post(site_url + 'login', frmData, function(responses) {
                    if (responses.success == true) {
                        $('#loginFrm').modal('hide');
                        swal({
                            title: 'Welcome back!',
                            text: responses.message,
                            timer: 3000,
                            type: 'success'
                        });
                        setTimeout(function () {
                            location.reload();
                        }, 2000);
                    } else {
                        swal('Đăng nhập thất bại', responses.message, 'error');
                    }
                    $('#frmDangnhap input[type="text"], #frmDangnhap button').attr('disabled', false);
                    $('#frmDangnhap button[type="submit"]').removeClass('loading');
                }).fail(function() {
                    swal('Đăng nhập thất bại', 'Lỗi kết nối', 'error');
                    $('#frmDangnhap input[type="text"], #frmDangnhap button').attr('disabled', false);
                    $('#frmDangnhap button[type="submit"]').removeClass('loading');
                });
                return false;
            });

            $('#frmQuenmatkhau').submit(function() {
                var forgot_step = $('#forgot_step').val().trim();
                var username = $('#forgot_username').val().trim();
                var confirm_code = $('#forgot_confirm_code').val().trim();
                var new_password = jQuery('#forgot_new_password').val().trim();
                if (username == '') {
                    showErrOfField('forgot_username');
                    return false;
                }
                if (confirm_code == '' && forgot_step == 'confirm') {
                    showErrOfField('forgot_confirm_code');
                    return false;
                }
                if (new_password == '' && forgot_step == 'final') {
                    showErrOfField('forgot_new_password');
                    return false;
                }

                var frmData = $('#frmQuenmatkhau').serializeArray();
                $('#frmQuenmatkhau input[type="text"], #frmQuenmatkhau button').attr('disabled', true);
                $('#frmQuenmatkhau button[type="submit"]').addClass('loading');
                $.post(site_url + 'forgot-' + forgot_step, frmData, function(responses) {
                    if (responses.success == true) {
                        if (forgot_step == 'request') {
                            $('#forgot_step').val('confirm');
                            $('#frmQuenmatkhau [type="submit"]').html('Xác nhận');
                            $('#step_request').hide();
                            $('#step_confirm').show();
                            setTimeout(function () {
                                $('#forgot_confirm_code').val('').focus();
                            }, 500);
                        }
                        if (forgot_step == 'confirm') {
                            $('#forgot_step').val('final');
                            $('#frmQuenmatkhau [type="submit"]').html('Đổi mật khẩu');
                            $('#step_confirm').hide();
                            $('#step_final').show();setTimeout(function () {
                                $('#forgot_new_password').val('').focus();
                            }, 500);
                        }
                        if (forgot_step == 'final') {
                            swal('Updated', responses.message, 'success');
                            setTimeout(function() {
                                $('#forgotFrm').modal('hide');

                                setTimeout(function () {
                                    $('#loginFrm').modal('setting', 'closable', false).modal('show');
                                }, 100);
                            }, 3000);
                        }
                    } else {
                        if (forgot_step == 'request') {
                            swal('Yêu cầu thất bại', responses.message, 'error');
                        }
                        if (forgot_step == 'confirm') {
                            swal('Xác nhận thất bại', responses.message, 'error');
                        }
                        if (forgot_step == 'final') {
                            swal('Đổi mật khẩu thất bại', responses.message, 'error');
                        }
                    }
                    $('#frmQuenmatkhau input[type="text"], #frmQuenmatkhau button').attr('disabled', false);
                    $('#frmQuenmatkhau button[type="submit"]').removeClass('loading');
                }).fail(function() {
                    swal('Đổi mật khẩu thất bại', 'Lỗi kết nối', 'error');
                    $('#frmQuenmatkhau input[type="text"], #frmQuenmatkhau button').attr('disabled', false);
                    $('#frmQuenmatkhau button[type="submit"]').removeClass('loading');
                });
                return false;
            });

            if ($('#page-menu').length && $('#page-menu li a.active').length) {
                $('#page-menu').animate({
                    scrollLeft: $('#page-menu li a.active').parent().offset().left - $('#page-menu li a.active').parent().width() / 2
                }, 500);
            }

            $('.ui.checkbox').checkbox();
            $('input[name="pickup"]').prop('checked', $.cookie('pickup') == 1);
        });

        function updateCart($item) {
            var note = $item.find('input.note').val().trim();
            var color = $item.find('input.color:checked').val();
            var qty = parseInt($item.find('input.qty').val());
            var id = $item.data('id');
            $item.find('.dimmer').addClass('active');
            $.post(site_url + 'add_cart', {
                id: id,
                qty: qty,
                note: note,
                color: color
            }, function(responses) {
                if (responses.success == true) {
                    $('.cart-badge').text(responses.data.numCart);
                    $('#numCart').text(responses.data.numCart);
                    $('#totalCart').text(responses.data.totalCart);
                    $('.numSubtotal').text(responses.data.totalCart);
                    $('.numVAT').text(responses.data.vat);
                    if (qty == 0) {
                        $item.remove();
                        $('#confirm .cart-list .cart-item[data-id="' + id + '"]').remove();
                    } else {
                        if (note == '') {
                            $('#confirm .cart-list .cart-item[data-id="' + id + '"] div.note').hide();
                            $('#confirm .cart-list .cart-item[data-id="' + id + '"] input.note').val(note).hide();
                        } else {
                            $('#confirm .cart-list .cart-item[data-id="' + id + '"] div.note').show();
                            $('#confirm .cart-list .cart-item[data-id="' + id + '"] input.note').val(note).show();
                        }
                        if (color == '') {
                            $('#confirm .cart-list .cart-item[data-id="' + id + '"] input.color').val(color).hide();
                        } else {
                            $('#confirm .cart-list .cart-item[data-id="' + id + '"] input.color').val(color).show();
                        }
                    }
                    //calcPayment();
                } else {
                    swal('Cập nhật giỏ hàng thất bại', responses.message, 'error');
                }
                $item.find('.dimmer').removeClass('active');
            }).fail(function() {
                swal('Cập nhật giỏ hàng thất bại', 'Lỗi kết nối', 'error');
                $item.find('.dimmer').removeClass('active');
            });
        }

        function loadDistrict($form) {
            $form.find('select[name="phuongxa"] option').not('[value="0"]').remove();
            $form.find('select[name="phuongxa"]').val(0).trigger('change');
            $form.find('select[name="quanhuyen"] option').not('[value="0"]').remove();
            $form.find('select[name="quanhuyen"]').val(0).trigger('change');
            $form.find('select[name="quanhuyen"]').parent().addClass('loading');
            $.post(site_url + 'list_city', {
                parent: $form.find('select[name="tinhthanh"]').val()
            }, function(responses) {
                $form.find('select[name="quanhuyen"]').parent().removeClass('loading');
                if (responses.success == true) {
                    for (i = 0; i < responses.data.length; i++) {
                        $form.find('select[name="quanhuyen"]').append('<option value="' + responses.data[i].id + '">' + (responses.data[i].pre ? responses.data[i].pre + ' ' : '') + responses.data[i].name_vn + '</option>');
                    }
                }
                if ($.cookie('quanhuyen') != 0 && $.cookie('quanhuyen') != null && $form.find('select[name="quanhuyen"] option[value="' + $.cookie('quanhuyen') + '"]').length) {
                    $form.find('select[name="quanhuyen"]').val($.cookie('quanhuyen'));
                }
                $form.find('select[name="quanhuyen"]').trigger('quanhuyen');
            }).fail(function() {
                $form.find('select[name="quanhuyen"]').parent().removeClass('loading');
                $form.find('select[name="quanhuyen"]').trigger('quanhuyen');
            });
        }

        function loadWard($form) {
            $form.find('select[name="phuongxa"] option').not('[value="0"]').remove();
            $form.find('select[name="phuongxa"]').val(0).trigger('change');
            $form.find('select[name="phuongxa"]').parent().addClass('loading');
            $.post(site_url + 'list_city', {
                parent: $form.find('select[name="quanhuyen"]').val()
            }, function(responses) {
                $form.find('select[name="phuongxa"]').parent().removeClass('loading');
                if (responses.success == true) {
                    for (i = 0; i < responses.data.length; i++) {
                        $form.find('select[name="phuongxa"]').append('<option value="' + responses.data[i].id + '">' + (responses.data[i].pre ? responses.data[i].pre + ' ' : '') + responses.data[i].name_vn + '</option>');
                    }
                }
                if ($.cookie('phuongxa') != 0 && $.cookie('phuongxa') != null && $form.find('select[name="phuongxa"] option[value="' + $.cookie('phuongxa') + '"]').length) {
                    $form.find('select[name="phuongxa"]').val($.cookie('phuongxa'));
                }
                $form.find('select[name="phuongxa"]').trigger('change');
            }).fail(function() {
                $form.find('select[name="phuongxa"]').parent().removeClass('loading');
                $form.find('select[name="phuongxa"]').trigger('change');
            });
        }

        function checkDistance($form) {
            var address = '';
            var adds = [];
            var quanhuyen = $form.find('select[name="quanhuyen"]').val();
            var phuongxa = $form.find('select[name="phuongxa"]').val();
            var street = $form.find('input[name="address"]').val().trim();
            var ward = $form.find('select[name="phuongxa"] option[value="' + phuongxa + '"]').text();
            var district = $form.find('select[name="quanhuyen"] option[value="' + quanhuyen + '"]').text();
            var city = 'Hà Nội';
            if (street != '' && quanhuyen != '0' && phuongxa != '0' && city != '') {
                adds.push(street);
                adds.push(ward);
                adds.push(district);
                adds.push(city);
                address = adds.join(', ');

                $form.addClass('loading');
                geocoder.geocode({
                    'address': address
                }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        var latitude = parseFloat(results[0].geometry.location.lat());
                        var longitude = parseFloat(results[0].geometry.location.lng());

                        var check = -1;
                        var user_latlng = new google.maps.LatLng(latitude, longitude);
                        var branchLatlng = null;
                        $('.branch-list').each(function () {
                            var latlng = new google.maps.LatLng(parseFloat($(this).data('latitude')), parseFloat($(this).data('longitude')));
                            var distance = parseFloat((google.maps.geometry.spherical.computeDistanceBetween(user_latlng, latlng) / 1000).toFixed(1));
                            if (check == -1 || distance < check) {
                                check = distance;
                                branchLatlng = latlng;
                                console.log(check);
                            }
                        });

                        if (branchLatlng != null) {
                            directionService.route({
                                origin: branchLatlng,
                                destination: user_latlng,
                                travelMode: google.maps.DirectionsTravelMode.DRIVING
                            }, function (response, status) {
                                if (status == google.maps.DirectionsStatus.OK) {
                                    var distance = Math.round(response.routes[0].legs[0].distance.value / 1000, 1);
                                    console.log(distance);
                                    if (distance <= 10) {
                                        $.cookie('latitude', latitude);
                                        $.cookie('longitude', longitude);
                                        $.cookie('distance', distance);
                                        $.cookie('quanhuyen', quanhuyen);
                                        $.cookie('phuongxa', phuongxa);
                                        $.cookie('street', street);

                                        $('select[name="quanhuyen"]').val(quanhuyen).trigger('change');
                                        $('select[name="phuongxa"]').val(phuongxa).trigger('change');
                                        $('input[name="address"]').val(street);

                                        $('#regionFrm').modal('hide');
                                    } else {
                                        $('#popupFrm').modal('setting', 'closable', false).modal('show');
                                    }
                                    $form.removeClass('loading');
                                } else {
                                    $form.removeClass('loading');
                                    $('#popupFrm').modal('setting', 'closable', false).modal('show');
                                }
                            });
                        } else {
                            $form.removeClass('loading');
                            $('#popupFrm').modal('setting', 'closable', false).modal('show');
                        }
                    } else {
                        $form.removeClass('loading');
                        $('#popupFrm').modal('setting', 'closable', false).modal('show');
                    }
                });
            }
        }

        function loadNews(id, href) {
            $('.news-item[data-id="' + id + '"] .dimmer').addClass('active');
            $.get(href, function(responses) {
                if (responses.success == true) {
                    $('#detailFrm .detail-images').empty();
                    $.each(responses.data.images, function (i, img) {
                        $('#detailFrm .detail-images').append('<div class="item"><img src="' + img + '" alt="" class="ui image"/></div>');
                    });
                    $('#detailFrm .detail-images').owlCarousel({
                        animateOut: 'fadeOut',
                        loop: true,
                        lazyLoad: true,
                        autoplay: true,
                        autoplayTimeout: 5000,
                        items: 1,
                        margin: 0,
                        stagePadding: 0,
                        smartSpeed: 450,
                        nav: false,
                        navText: ['', '']
                    });
                    $('#detailFrm .title-detail').text(responses.data.name_vn);
                    $('#detailFrm .share-url').html('<a href="https://www.facebook.com/sharer/sharer.php?u=' + responses.data.sharelink + '" target="_blank"><img src="assets/images/icon-share.svg" alt="" style="width: 24px; margin-top: 4px; margin-left: 3px;"></a>');
                    $('#detailFrm .time-detail').text(responses.data.date_added);
                    $('#detailFrm .info-detail').html(responses.data.info_vn);
                    $('#detailFrm').modal('setting', 'closable', false).modal('show');
                }
                $('.news-item[data-id="' + id + '"] .dimmer').removeClass('active');
            }).fail(function() {
                $('.news-item[data-id="' + id + '"] .dimmer').removeClass('active');
                swal('Tải nội dung bài viết thất bại', 'Lỗi kết nối', 'error');
            });
        }
    </script>
</body>
</html>